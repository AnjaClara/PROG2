#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <stdbool.h>
#include <time.h>
#include <math.h>

#define MAX_LINE_LENGTH 1000
#define NUM_STUDENTS 50

typedef struct {
    char NU_INSCRICAO[15];
    char NO_MUNICIPIO_RESIDENCIA[100];
    int NU_IDADE;
    char TP_SEXO[2];
    double NU_NOTA_CN;
    double NU_NOTA_CH;
    double NU_NOTA_LC;
    double NU_NOTA_MT;
    double NU_NOTA_REDACAO;
    double mediaNotas;
} StudentData;

typedef enum {
    NU_INSCRICAO,
    NO_MUNICIPIO_RESIDENCIA,
    NU_IDADE,
    TP_SEXO,
    NU_NOTA_CN,
    NU_NOTA_CH,
    NU_NOTA_LC,
    NU_NOTA_MT,
    NU_NOTA_REDACAO
} CSVColumns;

typedef struct {
    CSVColumns column;
    const char *columnName;
} Factor;

double calculateMean(StudentData *students, int numStudents, CSVColumns column) {
    double sum = 0.0;

    for (int i = 0; i < numStudents; i++) {
        switch (column) {
            case NU_NOTA_CN:
                sum += students[i].NU_NOTA_CN;
                break;
            case NU_NOTA_CH:
                sum += students[i].NU_NOTA_CH;
                break;
            case NU_NOTA_LC:
                sum += students[i].NU_NOTA_LC;
                break;
            case NU_NOTA_MT:
                sum += students[i].NU_NOTA_MT;
                break;
            case NU_NOTA_REDACAO:
                sum += students[i].NU_NOTA_REDACAO;
                break;
        }
    }

    return sum / numStudents;
}

double calculateCorrelation(StudentData *students, int numStudents, CSVColumns column, double meanColumn, double meanNotes) {
    double numerator = 0.0;
    double denominator1 = 0.0;
    double denominator2 = 0.0;

    for (int i = 0; i < numStudents; i++) {
        double diffColumn = 0.0;
        double diffNotes = 0.0;

        switch (column) {
            case NU_NOTA_CN:
                diffColumn = students[i].NU_NOTA_CN - meanColumn;
                break;
            case NU_NOTA_CH:
                diffColumn = students[i].NU_NOTA_CH - meanColumn;
                break;
            case NU_NOTA_LC:
                diffColumn = students[i].NU_NOTA_LC - meanColumn;
                break;
            case NU_NOTA_MT:
                diffColumn = students[i].NU_NOTA_MT - meanColumn;
                break;
            case NU_NOTA_REDACAO:
                diffColumn = students[i].NU_NOTA_REDACAO - meanColumn;
                break;
        }

        diffNotes = students[i].mediaNotas - meanNotes;

        numerator += diffColumn * diffNotes;
        denominator1 += pow(diffColumn, 2);
        denominator2 += pow(diffNotes, 2);
    }

    double denominator = sqrt(denominator1 * denominator2);
    if (denominator == 0.0) {
        return 0.0; // Correlation undefined
    } else {
        return numerator / denominator;
    }
}

void selectRandomStudents(StudentData *students, int numStudents, StudentData *selectedStudents) {
    int selectedIndices[NUM_STUDENTS] = {0};

    for (int i = 0; i < NUM_STUDENTS; i++) {
        bool alreadySelected = false;
        int randomIndex;

        do {
            randomIndex = rand() % numStudents;

            for (int j = 0; j < i; j++) {
                if (selectedIndices[j] == randomIndex) {
                    alreadySelected = true;
                    break;
                }
            }
        } while (alreadySelected);

        selectedIndices[i] = randomIndex;
        selectedStudents[i] = students[randomIndex];
    }
}

void calculateAverage(StudentData *students, int numStudents) {
    for (int i = 0; i < numStudents; i++) {
        students[i].mediaNotas = (students[i].NU_NOTA_CN + students[i].NU_NOTA_CH +
                                  students[i].NU_NOTA_LC + students[i].NU_NOTA_MT +
                                  students[i].NU_NOTA_REDACAO) / 5.0;
    }
}

void printResults(StudentData *selectedStudents, int numStudents) {
    printf("NU_INSCRICAO\tMEDIA_NOTAS\n");

    for (int i = 0; i < numStudents; i++) {
        printf("%s\t\t%.2lf\n", selectedStudents[i].NU_INSCRICAO, selectedStudents[i].mediaNotas);
    }
}

void saveResultsToCSV(StudentData *selectedStudents, int numStudents) {
    FILE *file = fopen("resultados.csv", "w");
    if (file == NULL) {
        printf("Erro ao criar o arquivo 'resultados.csv'.\n");
        return;
    }

    fprintf(file, "NU_INSCRICAO,MEDIA_NOTAS\n");

    for (int i = 0; i < numStudents; i++) {
        fprintf(file, "%s,%.2lf\n", selectedStudents[i].NU_INSCRICAO, selectedStudents[i].mediaNotas);
    }

    fclose(file);

    printf("\nNovo arquivo CSV criado: resultados.csv\n\n");
}

int getColumnIndex(const char *columnName) {
    if (strcmp(columnName, "NU_INSCRICAO") == 0) {
        return NU_INSCRICAO;
    } else if (strcmp(columnName, "NO_MUNICIPIO_RESIDENCIA") == 0) {
        return NO_MUNICIPIO_RESIDENCIA;
    } else if (strcmp(columnName, "NU_IDADE") == 0) {
        return NU_IDADE;
    } else if (strcmp(columnName, "TP_SEXO") == 0) {
        return TP_SEXO;
    } else if (strcmp(columnName, "NU_NOTA_CN") == 0) {
        return NU_NOTA_CN;
    } else if (strcmp(columnName, "NU_NOTA_CH") == 0) {
        return NU_NOTA_CH;
    } else if (strcmp(columnName, "NU_NOTA_LC") == 0) {
        return NU_NOTA_LC;
    } else if (strcmp(columnName, "NU_NOTA_MT") == 0) {
        return NU_NOTA_MT;
    } else if (strcmp(columnName, "NU_NOTA_REDACAO") == 0) {
        return NU_NOTA_REDACAO;
    } else {
        return -1; // Column not found
    }
}

void analyzeFactors(StudentData *selectedStudents, int numStudents) {
    printf("Fatores disponíveis:\n");
    printf("1. NU_INSCRICAO\n");
    printf("2. NO_MUNICIPIO_RESIDENCIA\n");
    printf("3. NU_IDADE\n");
    printf("4. TP_SEXO\n");
    printf("5. NU_NOTA_CN\n");
    printf("6. NU_NOTA_CH\n");
    printf("7. NU_NOTA_LC\n");
    printf("8. NU_NOTA_MT\n");
    printf("9. NU_NOTA_REDACAO\n");

    printf("\nInforme os números dos fatores a serem analisados (separados por vírgula): ");
    char inputFactors[100];
    fgets(inputFactors, sizeof(inputFactors), stdin);

    const char *delimiters = ",\n";
    char *token = strtok(inputFactors, delimiters);
    Factor selectedFactors[10];
    int numSelectedFactors = 0;

    while (token != NULL) {
        int factorIndex = atoi(token);
        if (factorIndex >= 1 && factorIndex <= 9) {
            selectedFactors[numSelectedFactors].column = factorIndex - 1;
            selectedFactors[numSelectedFactors].columnName = "";

            numSelectedFactors++;
        }
        token = strtok(NULL, delimiters);
    }

    if (numSelectedFactors == 0) {
        printf("\nNenhum fator selecionado.\n");
        return;
    }

    printf("\nInforme o nível de significância para o teste de hipótese: ");
    double significanceLevel;
    scanf("%lf", &significanceLevel);

    printf("\nFatores selecionados:\n");
    for (int i = 0; i < numSelectedFactors; i++) {
        switch (selectedFactors[i].column) {
            case NU_INSCRICAO:
                selectedFactors[i].columnName = "NU_INSCRICAO";
                break;
            case NO_MUNICIPIO_RESIDENCIA:
                selectedFactors[i].columnName = "NO_MUNICIPIO_RESIDENCIA";
                break;
            case NU_IDADE:
                selectedFactors[i].columnName = "NU_IDADE";
                break;
            case TP_SEXO:
                selectedFactors[i].columnName = "TP_SEXO";
                break;
            case NU_NOTA_CN:
                selectedFactors[i].columnName = "NU_NOTA_CN";
                break;
            case NU_NOTA_CH:
                selectedFactors[i].columnName = "NU_NOTA_CH";
                break;
            case NU_NOTA_LC:
                selectedFactors[i].columnName = "NU_NOTA_LC";
                break;
            case NU_NOTA_MT:
                selectedFactors[i].columnName = "NU_NOTA_MT";
                break;
            case NU_NOTA_REDACAO:
                selectedFactors[i].columnName = "NU_NOTA_REDACAO";
                break;
        }
        printf("%d. %s\n", i + 1, selectedFactors[i].columnName);
    }

    printf("\nAnálise de correlação:\n");
    printf("Fator\t\tCorrelação\t\tSignificância\n");

    for (int i = 0; i < numSelectedFactors; i++) {
        double factorMean = calculateMean(selectedStudents, numStudents, selectedFactors[i].column);
        double correlation = calculateCorrelation(selectedStudents, numStudents, selectedFactors[i].column, factorMean, selectedStudents[i].mediaNotas);

        printf("%s\t\t%.2lf\t\t", selectedFactors[i].columnName, correlation);
        if (fabs(correlation) >= significanceLevel) {
            printf("Significativo\n");
        } else {
            printf("Não significativo\n");
        }
    }
}

int main() {
    FILE *file = fopen("enem2016.csv", "r");
    if (file == NULL) {
        printf("Erro ao abrir o arquivo 'enem2016.csv'. Certifique-se de que o arquivo existe e está no diretório correto.\n");
        return 1;
    }

    char line[MAX_LINE_LENGTH];
    StudentData students[10000];
    int numStudents = 0;

    while (fgets(line, sizeof(line), file)) {
        if (numStudents == 10000) {
            printf("O número máximo de alunos foi atingido.\n");
            break;
        }

        char *token = strtok(line, ",");
        int columnIndex = 0;

        while (token != NULL) {
            switch (columnIndex) {
                case NU_INSCRICAO:
                    strncpy(students[numStudents].NU_INSCRICAO, token, sizeof(students[numStudents].NU_INSCRICAO));
                    break;
                case NO_MUNICIPIO_RESIDENCIA:
                    strncpy(students[numStudents].NO_MUNICIPIO_RESIDENCIA, token, sizeof(students[numStudents].NO_MUNICIPIO_RESIDENCIA));
                    break;
                case NU_IDADE:
                    students[numStudents].NU_IDADE = atoi(token);
                    break;
                case TP_SEXO:
                    strncpy(students[numStudents].TP_SEXO, token, sizeof(students[numStudents].TP_SEXO));
                    break;
                case NU_NOTA_CN:
                    students[numStudents].NU_NOTA_CN = atof(token);
                    break;
                case NU_NOTA_CH:
                    students[numStudents].NU_NOTA_CH = atof(token);
                    break;
                case NU_NOTA_LC:
                    students[numStudents].NU_NOTA_LC = atof(token);
                    break;
                case NU_NOTA_MT:
                    students[numStudents].NU_NOTA_MT = atof(token);
                    break;
                case NU_NOTA_REDACAO:
                    students[numStudents].NU_NOTA_REDACAO = atof(token);
                    break;
            }

            token = strtok(NULL, ",");
            columnIndex++;
        }

        numStudents++;
    }

    fclose(file);

    srand(time(NULL));

    StudentData selectedStudents[NUM_STUDENTS];
    selectRandomStudents(students, numStudents, selectedStudents);

    calculateAverage(selectedStudents, NUM_STUDENTS);

    printResults(selectedStudents, NUM_STUDENTS);

    saveResultsToCSV(selectedStudents, NUM_STUDENTS);

    analyzeFactors(selectedStudents, NUM_STUDENTS);

    return 0;
}
